<?php declare(strict_types=1);

namespace App\ThirdParty;

trait ClientDomain
{
    /**
     * @var string
     */
    private static string $baseUrl = 'http://jsonplaceholder.typicode.com';
}
